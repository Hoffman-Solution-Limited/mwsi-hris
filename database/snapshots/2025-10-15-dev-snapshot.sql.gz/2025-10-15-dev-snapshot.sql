--
-- PostgreSQL database dump
--

\restrict a6PGKcMFZO0TvW67EULqo2hR9mlwK3GSVkmBot6b6EgVeFeCSewfCFHGnKggvY7

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: department_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.department_goals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    department text NOT NULL,
    title text NOT NULL,
    description text,
    owner_employee_id text,
    target_date date,
    progress integer DEFAULT 0,
    status text DEFAULT 'active'::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: disciplinary_case_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disciplinary_case_updates (
    id integer NOT NULL,
    case_id character varying(50),
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    text text
);


--
-- Name: disciplinary_case_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.disciplinary_case_updates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: disciplinary_case_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.disciplinary_case_updates_id_seq OWNED BY public.disciplinary_case_updates.id;


--
-- Name: disciplinary_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disciplinary_cases (
    id character varying(50) NOT NULL,
    employee_id character varying(50),
    employee_name character varying(200),
    case_type character varying(200),
    status character varying(50),
    date date,
    description text,
    verdict text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updates jsonb
);


--
-- Name: document_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_types (
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_files (
    employee_id character varying(50) NOT NULL,
    current_location character varying(200) NOT NULL,
    assigned_user_id character varying(50),
    assigned_user_name character varying(200),
    default_documents text[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_skills (
    id integer NOT NULL,
    employee_id character varying(50),
    name character varying(200) NOT NULL,
    level character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_skills_id_seq OWNED BY public.employee_skills.id;


--
-- Name: employee_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_targets (
    id integer NOT NULL,
    review_id character varying(50),
    criteria_id character varying(50) NOT NULL,
    target text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_targets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_targets_id_seq OWNED BY public.employee_targets.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id character varying(50) NOT NULL,
    employee_number character varying(50),
    name character varying(200) NOT NULL,
    email character varying(200),
    "position" character varying(200),
    department character varying(100),
    manager character varying(200),
    manager_id character varying(50),
    hire_date date,
    status character varying(20) DEFAULT 'active'::character varying,
    avatar text,
    phone character varying(50),
    emergency_contact text,
    salary numeric(12,2),
    gender character varying(20),
    cadre character varying(50),
    employment_type character varying(100),
    engagement_type character varying(100),
    job_group character varying(50),
    ethnicity character varying(100),
    national_id character varying(50),
    kra_pin character varying(50),
    children character varying(10),
    work_county character varying(100),
    home_county character varying(100),
    postal_address text,
    postal_code character varying(20),
    station_name character varying(200),
    skill_level text,
    company text,
    date_of_birth date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    next_of_kin_name text,
    next_of_kin_relationship text,
    next_of_kin_phone text,
    next_of_kin_email text,
    has_special_needs boolean,
    special_needs_description text,
    home_subcounty text,
    marital_status character varying(32),
    CONSTRAINT employees_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'terminated'::character varying])::text[])))
);


--
-- Name: file_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_movements (
    id integer NOT NULL,
    employee_id character varying(50),
    by_user_id character varying(50),
    by_user_name character varying(200),
    from_location character varying(200),
    to_location character varying(200),
    to_assignee_user_id character varying(50),
    to_assignee_name character varying(200),
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    remarks text
);


--
-- Name: file_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.file_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.file_movements_id_seq OWNED BY public.file_movements.id;


--
-- Name: file_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_requests (
    id character varying(100) NOT NULL,
    file_id character varying(50),
    employee_id character varying(50),
    document_type character varying(200),
    requested_by_user_id character varying(50),
    requested_by_name character varying(200),
    requested_by_department character varying(200),
    status character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    remarks text
);


--
-- Name: leave_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_requests (
    id character varying(50) NOT NULL,
    employee_id character varying(50),
    employee_name character varying(200),
    type character varying(50),
    start_date date,
    end_date date,
    days integer,
    status character varying(50),
    reason text,
    applied_date date,
    manager_comments text,
    hr_comments text,
    approved_by character varying(200),
    approved_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id character varying(50) NOT NULL,
    user_id character varying(50),
    title character varying(300),
    message text,
    link character varying(300),
    type character varying(50),
    read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: performance_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.performance_reviews (
    id character varying(50) NOT NULL,
    employee_id character varying(50),
    employee_name character varying(200),
    employee_number character varying(50),
    template_id character varying(50),
    review_period character varying(100),
    employee_self_comments text,
    employee_ack_status character varying(20),
    employee_ack_comments text,
    employee_ack_date date,
    status character varying(50),
    overall_score numeric(5,2),
    score numeric(5,2),
    manager_comments text,
    hr_comments text,
    goals text[],
    feedback text,
    employee_targets jsonb,
    manager_scores jsonb,
    employee_scores jsonb,
    next_review_date date,
    created_by character varying(200),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: performance_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.performance_scores (
    id integer NOT NULL,
    review_id character varying(50),
    criteria_id character varying(50) NOT NULL,
    score_by character varying(20),
    score integer,
    comments text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: performance_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.performance_scores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: performance_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.performance_scores_id_seq OWNED BY public.performance_scores.id;


--
-- Name: performance_template_criteria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.performance_template_criteria (
    id integer NOT NULL,
    template_id character varying(50),
    criteria_id character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    weight numeric(5,2) NOT NULL,
    description text
);


--
-- Name: performance_template_criteria_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.performance_template_criteria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: performance_template_criteria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.performance_template_criteria_id_seq OWNED BY public.performance_template_criteria.id;


--
-- Name: performance_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.performance_templates (
    id character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(50),
    description text,
    department character varying(100),
    created_by character varying(200),
    created_at date
);


--
-- Name: positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.positions (
    id character varying(50) DEFAULT (public.uuid_generate_v4())::text NOT NULL,
    title character varying(200) NOT NULL,
    department character varying(100),
    status character varying(20) DEFAULT 'open'::character varying,
    priority character varying(20),
    applicants integer DEFAULT 0,
    posted_date date,
    closing_date date,
    description text,
    designation character varying(200),
    skill_level character varying(200),
    station_name character varying(200),
    job_group character varying(50),
    employment_type character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    stations text[],
    gross_salary numeric,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT positions_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'filled'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id character varying(100) NOT NULL,
    permission_key character varying(200) NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id character varying(100) NOT NULL,
    name character varying(200) NOT NULL,
    locked boolean DEFAULT false,
    meta jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: system_designations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_designations (
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: system_engagement_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_engagement_types (
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: system_ethnicities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_ethnicities (
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: system_job_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_job_groups (
    name character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_logs (
    id character varying(50) NOT NULL,
    action character varying(300),
    user_id character varying(50),
    details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: system_skill_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_skill_levels (
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: system_stations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_stations (
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: training_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.training_records (
    id character varying(50) NOT NULL,
    employee_id character varying(50),
    title character varying(300) NOT NULL,
    type character varying(50),
    status character varying(50),
    completion_date date,
    expiry_date date,
    provider character varying(200),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    archived boolean DEFAULT false
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying(50) NOT NULL,
    employee_id character varying(50),
    email character varying(200) NOT NULL,
    name character varying(200),
    role character varying(100),
    password text,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'terminated'::character varying])::text[])))
);


--
-- Name: disciplinary_case_updates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disciplinary_case_updates ALTER COLUMN id SET DEFAULT nextval('public.disciplinary_case_updates_id_seq'::regclass);


--
-- Name: employee_skills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_skills ALTER COLUMN id SET DEFAULT nextval('public.employee_skills_id_seq'::regclass);


--
-- Name: employee_targets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_targets ALTER COLUMN id SET DEFAULT nextval('public.employee_targets_id_seq'::regclass);


--
-- Name: file_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_movements ALTER COLUMN id SET DEFAULT nextval('public.file_movements_id_seq'::regclass);


--
-- Name: performance_scores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_scores ALTER COLUMN id SET DEFAULT nextval('public.performance_scores_id_seq'::regclass);


--
-- Name: performance_template_criteria id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_template_criteria ALTER COLUMN id SET DEFAULT nextval('public.performance_template_criteria_id_seq'::regclass);


--
-- Data for Name: department_goals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.department_goals VALUES ('11111111-1111-1111-1111-111111111111', 'Engineering', 'Improve deployment cadence', 'Reduce release cycle time by improving CI/CD and automation', NULL, '2026-03-31', 10, 'active', '2025-10-12 19:42:32.543043+00', '2025-10-12 19:42:32.543043+00');
INSERT INTO public.department_goals VALUES ('22222222-2222-2222-2222-222222222222', 'Human Resources', 'Increase employee engagement', 'Run quarterly engagement surveys and follow-up actions', NULL, '2026-12-31', 25, 'active', '2025-10-12 19:42:32.543043+00', '2025-10-12 19:42:32.543043+00');
INSERT INTO public.department_goals VALUES ('33333333-3333-3333-3333-333333333333', 'Marketing', 'Boost inbound leads', 'Improve content pipeline and channel mix to increase inbound leads', NULL, '2026-06-30', 5, 'active', '2025-10-12 19:42:32.543043+00', '2025-10-12 19:42:32.543043+00');


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.departments VALUES ('IT', 'IT Department', '2025-10-12 18:47:57.401101+00');
INSERT INTO public.departments VALUES ('Human Resources', 'Human Resources', '2025-10-12 18:47:57.401101+00');
INSERT INTO public.departments VALUES ('Engineering', 'Engineering Department', '2025-10-12 18:47:57.401101+00');
INSERT INTO public.departments VALUES ('Marketing', 'Marketing Department', '2025-10-12 18:47:57.401101+00');
INSERT INTO public.departments VALUES ('Finance', 'Finance Department', '2025-10-12 18:47:57.401101+00');
INSERT INTO public.departments VALUES ('Operations', 'Operations Department', '2025-10-12 18:47:57.401101+00');
INSERT INTO public.departments VALUES ('Registry', 'Registry Department', '2025-10-12 18:47:57.401101+00');


--
-- Data for Name: disciplinary_case_updates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.disciplinary_case_updates VALUES (1, '1', '2025-07-13 10:15:00+00', 'HR reached out to employee for explanation.');
INSERT INTO public.disciplinary_case_updates VALUES (2, '1', '2025-07-14 08:30:00+00', 'Employee provided medical certificate; manager asked for formal leave application.');
INSERT INTO public.disciplinary_case_updates VALUES (3, '2', '2025-08-03 09:00:00+00', 'Waiting disciplinary committee update.');
INSERT INTO public.disciplinary_case_updates VALUES (4, '2', '2025-08-10 12:00:00+00', 'Committee requested witness statements; interviews scheduled.');
INSERT INTO public.disciplinary_case_updates VALUES (5, '3', '2025-06-15 14:30:00+00', 'Final meeting held with the employee and manager.');
INSERT INTO public.disciplinary_case_updates VALUES (6, '3', '2025-06-20 16:00:00+00', 'Case closed with final warning issued.');
INSERT INTO public.disciplinary_case_updates VALUES (7, '4', '2025-09-02 11:00:00+00', 'IT suspended affected accounts; investigation underway.');
INSERT INTO public.disciplinary_case_updates VALUES (8, '4', '2025-09-05 09:45:00+00', 'Employee interviewed; awaiting committee findings.');
INSERT INTO public.disciplinary_case_updates VALUES (9, '5', '2025-10-02 08:00:00+00', 'Safety officer filed incident report and recommended suspension pending review.');
INSERT INTO public.disciplinary_case_updates VALUES (10, '1', '2025-07-13 10:15:00+00', 'HR reached out to employee for explanation.');
INSERT INTO public.disciplinary_case_updates VALUES (11, '1', '2025-07-14 08:30:00+00', 'Employee provided medical certificate; manager asked for formal leave application.');
INSERT INTO public.disciplinary_case_updates VALUES (12, '2', '2025-08-03 09:00:00+00', 'Waiting disciplinary committee update.');
INSERT INTO public.disciplinary_case_updates VALUES (13, '2', '2025-08-10 12:00:00+00', 'Committee requested witness statements; interviews scheduled.');
INSERT INTO public.disciplinary_case_updates VALUES (14, '3', '2025-06-15 14:30:00+00', 'Final meeting held with the employee and manager.');
INSERT INTO public.disciplinary_case_updates VALUES (15, '3', '2025-06-20 16:00:00+00', 'Case closed with final warning issued.');
INSERT INTO public.disciplinary_case_updates VALUES (16, '4', '2025-09-02 11:00:00+00', 'IT suspended affected accounts; investigation underway.');
INSERT INTO public.disciplinary_case_updates VALUES (17, '4', '2025-09-05 09:45:00+00', 'Employee interviewed; awaiting committee findings.');
INSERT INTO public.disciplinary_case_updates VALUES (18, '5', '2025-10-02 08:00:00+00', 'Safety officer filed incident report and recommended suspension pending review.');
INSERT INTO public.disciplinary_case_updates VALUES (19, '1', '2025-07-13 10:15:00+00', 'HR reached out to employee for explanation.');
INSERT INTO public.disciplinary_case_updates VALUES (20, '1', '2025-07-14 08:30:00+00', 'Employee provided medical certificate; manager asked for formal leave application.');
INSERT INTO public.disciplinary_case_updates VALUES (21, '2', '2025-08-03 09:00:00+00', 'Waiting disciplinary committee update.');
INSERT INTO public.disciplinary_case_updates VALUES (22, '2', '2025-08-10 12:00:00+00', 'Committee requested witness statements; interviews scheduled.');
INSERT INTO public.disciplinary_case_updates VALUES (23, '3', '2025-06-15 14:30:00+00', 'Final meeting held with the employee and manager.');
INSERT INTO public.disciplinary_case_updates VALUES (24, '3', '2025-06-20 16:00:00+00', 'Case closed with final warning issued.');
INSERT INTO public.disciplinary_case_updates VALUES (25, '4', '2025-09-02 11:00:00+00', 'IT suspended affected accounts; investigation underway.');
INSERT INTO public.disciplinary_case_updates VALUES (26, '4', '2025-09-05 09:45:00+00', 'Employee interviewed; awaiting committee findings.');
INSERT INTO public.disciplinary_case_updates VALUES (27, '5', '2025-10-02 08:00:00+00', 'Safety officer filed incident report and recommended suspension pending review.');
INSERT INTO public.disciplinary_case_updates VALUES (28, '1', '2025-07-13 10:15:00+00', 'HR reached out to employee for explanation.');
INSERT INTO public.disciplinary_case_updates VALUES (29, '1', '2025-07-14 08:30:00+00', 'Employee provided medical certificate; manager asked for formal leave application.');
INSERT INTO public.disciplinary_case_updates VALUES (30, '2', '2025-08-03 09:00:00+00', 'Waiting disciplinary committee update.');
INSERT INTO public.disciplinary_case_updates VALUES (31, '2', '2025-08-10 12:00:00+00', 'Committee requested witness statements; interviews scheduled.');
INSERT INTO public.disciplinary_case_updates VALUES (32, '3', '2025-06-15 14:30:00+00', 'Final meeting held with the employee and manager.');
INSERT INTO public.disciplinary_case_updates VALUES (33, '3', '2025-06-20 16:00:00+00', 'Case closed with final warning issued.');
INSERT INTO public.disciplinary_case_updates VALUES (34, '4', '2025-09-02 11:00:00+00', 'IT suspended affected accounts; investigation underway.');
INSERT INTO public.disciplinary_case_updates VALUES (35, '4', '2025-09-05 09:45:00+00', 'Employee interviewed; awaiting committee findings.');
INSERT INTO public.disciplinary_case_updates VALUES (36, '5', '2025-10-02 08:00:00+00', 'Safety officer filed incident report and recommended suspension pending review.');


--
-- Data for Name: disciplinary_cases; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.disciplinary_cases VALUES ('1', '1', 'John Smith', 'Absenteeism', 'open', '2025-07-12', 'Missed work for 3 consecutive days without notice.', NULL, '2025-10-12 18:47:57.447014+00', NULL);
INSERT INTO public.disciplinary_cases VALUES ('2', '3', 'Michael Davis', 'Misconduct', 'pending', '2025-08-01', 'Unprofessional behavior towards a colleague.', NULL, '2025-10-12 18:47:57.447014+00', NULL);
INSERT INTO public.disciplinary_cases VALUES ('3', '4', 'Emily Chen', 'Performance', 'closed', '2025-06-20', 'Repeatedly failed to meet deadlines.', 'Final warning issued; performance improvement plan for 60 days.', '2025-10-12 18:47:57.447014+00', NULL);
INSERT INTO public.disciplinary_cases VALUES ('4', '6', 'Jane Smith', 'Policy Violation', 'pending', '2025-09-01', 'Breach of information security policy by sharing credentials.', NULL, '2025-10-12 18:47:57.447014+00', NULL);
INSERT INTO public.disciplinary_cases VALUES ('5', '7', 'Robert Chen', 'Health & Safety', 'open', '2025-10-01', 'Unsafe conduct in the workplace that endangered others.', NULL, '2025-10-12 18:47:57.447014+00', NULL);
INSERT INTO public.disciplinary_cases VALUES ('501c3c75-c0f4-4049-abcb-780cfc86e31b', '1', 'Smoke Tester', 'misconduct', 'open', '2025-10-12', 'Smoke test case for employee 1', NULL, '2025-10-12 20:51:19.568944+00', '[]');
INSERT INTO public.disciplinary_cases VALUES ('b004a258-7d92-408a-be56-288a17b60509', '1', 'Smoke Validator', 'misconduct', 'open', '2025-10-12', 'Validation test', NULL, '2025-10-12 20:58:36.856823+00', '[]');


--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_types VALUES ('Birth_Certificate', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('National_ID_Card', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('Current_Passport_Photo', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('KRA_PIN', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('Letter_of_First_Appointment', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('Letter_of_Confirmation', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('All_Promotion_Letters', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('Secondment_Letter', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('Next_of_Kin_GP25', '2025-10-12 18:47:57.453038+00');
INSERT INTO public.document_types VALUES ('Professional_and_Academic_Certificates', '2025-10-12 18:47:57.453038+00');


--
-- Data for Name: employee_files; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.employee_files VALUES ('1', 'Registry Office', NULL, NULL, '{Birth_Certificate,National_ID_Card,Current_Passport_Photo,KRA_PIN,Letter_of_First_Appointment,Letter_of_Confirmation,All_Promotion_Letters,Secondment_Letter,Next_of_Kin_GP25,Professional_and_Academic_Certificates}', '2025-10-12 18:47:57.457243+00', '2025-10-12 18:47:57.457243+00');
INSERT INTO public.employee_files VALUES ('2', 'Registry Office', NULL, NULL, '{Birth_Certificate,National_ID_Card,Current_Passport_Photo,KRA_PIN,Letter_of_First_Appointment,Letter_of_Confirmation,All_Promotion_Letters,Secondment_Letter,Next_of_Kin_GP25,Professional_and_Academic_Certificates}', '2025-10-12 18:47:57.457243+00', '2025-10-12 18:47:57.457243+00');
INSERT INTO public.employee_files VALUES ('3', 'Registry Office', NULL, NULL, '{Birth_Certificate,National_ID_Card,Current_Passport_Photo,KRA_PIN,Letter_of_First_Appointment,Letter_of_Confirmation,All_Promotion_Letters,Secondment_Letter,Next_of_Kin_GP25,Professional_and_Academic_Certificates}', '2025-10-12 18:47:57.457243+00', '2025-10-12 18:47:57.457243+00');


--
-- Data for Name: employee_skills; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.employee_skills VALUES (1, '1', 'Networking', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (2, '1', 'Linux Administration', 'Expert', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (3, '1', 'Cybersecurity', 'Intermediate', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (4, '2', 'Recruitment', 'Expert', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (5, '2', 'Employee Relations', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (6, '2', 'Conflict Resolution', 'Intermediate', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (7, '3', 'React', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (8, '3', 'Node.js', 'Intermediate', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (9, '3', 'TypeScript', 'Intermediate', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (10, '4', 'Content Marketing', 'Intermediate', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (11, '4', 'SEO', 'Beginner', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (12, '4', 'Social Media', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (13, '5', 'Financial Planning', 'Expert', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (14, '5', 'Risk Management', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (15, '5', 'Budgeting', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (16, '6', 'Python', 'Expert', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (17, '6', 'Django', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (18, '6', 'PostgreSQL', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (19, '7', 'Docker', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (20, '7', 'Kubernetes', 'Intermediate', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (21, '7', 'AWS', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (22, '10', 'Operations Management', 'Expert', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (23, '10', 'Leadership', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (24, '10', 'Process Improvement', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (25, '12', 'Document Management', 'Expert', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (26, '12', 'Record Keeping', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (27, '12', 'Compliance', 'Advanced', '2025-10-12 18:47:57.415586+00');
INSERT INTO public.employee_skills VALUES (28, '1', 'Networking', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (29, '1', 'Linux Administration', 'Expert', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (30, '1', 'Cybersecurity', 'Intermediate', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (31, '2', 'Recruitment', 'Expert', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (32, '2', 'Employee Relations', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (33, '2', 'Conflict Resolution', 'Intermediate', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (34, '3', 'React', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (35, '3', 'Node.js', 'Intermediate', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (36, '3', 'TypeScript', 'Intermediate', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (37, '4', 'Content Marketing', 'Intermediate', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (38, '4', 'SEO', 'Beginner', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (39, '4', 'Social Media', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (40, '5', 'Financial Planning', 'Expert', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (41, '5', 'Risk Management', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (42, '5', 'Budgeting', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (43, '6', 'Python', 'Expert', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (44, '6', 'Django', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (45, '6', 'PostgreSQL', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (46, '7', 'Docker', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (47, '7', 'Kubernetes', 'Intermediate', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (48, '7', 'AWS', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (49, '10', 'Operations Management', 'Expert', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (50, '10', 'Leadership', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (51, '10', 'Process Improvement', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (52, '12', 'Document Management', 'Expert', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (53, '12', 'Record Keeping', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (54, '12', 'Compliance', 'Advanced', '2025-10-12 18:49:00.537043+00');
INSERT INTO public.employee_skills VALUES (55, '1', 'Networking', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (56, '1', 'Linux Administration', 'Expert', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (57, '1', 'Cybersecurity', 'Intermediate', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (58, '2', 'Recruitment', 'Expert', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (59, '2', 'Employee Relations', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (60, '2', 'Conflict Resolution', 'Intermediate', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (61, '3', 'React', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (62, '3', 'Node.js', 'Intermediate', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (63, '3', 'TypeScript', 'Intermediate', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (64, '4', 'Content Marketing', 'Intermediate', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (65, '4', 'SEO', 'Beginner', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (66, '4', 'Social Media', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (67, '5', 'Financial Planning', 'Expert', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (68, '5', 'Risk Management', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (69, '5', 'Budgeting', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (70, '6', 'Python', 'Expert', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (71, '6', 'Django', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (72, '6', 'PostgreSQL', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (73, '7', 'Docker', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (74, '7', 'Kubernetes', 'Intermediate', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (75, '7', 'AWS', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (76, '10', 'Operations Management', 'Expert', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (77, '10', 'Leadership', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (78, '10', 'Process Improvement', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (79, '12', 'Document Management', 'Expert', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (80, '12', 'Record Keeping', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (81, '12', 'Compliance', 'Advanced', '2025-10-12 18:51:04.289296+00');
INSERT INTO public.employee_skills VALUES (82, '1', 'Networking', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (83, '1', 'Linux Administration', 'Expert', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (84, '1', 'Cybersecurity', 'Intermediate', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (85, '2', 'Recruitment', 'Expert', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (86, '2', 'Employee Relations', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (87, '2', 'Conflict Resolution', 'Intermediate', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (88, '3', 'React', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (89, '3', 'Node.js', 'Intermediate', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (90, '3', 'TypeScript', 'Intermediate', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (91, '4', 'Content Marketing', 'Intermediate', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (92, '4', 'SEO', 'Beginner', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (93, '4', 'Social Media', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (94, '5', 'Financial Planning', 'Expert', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (95, '5', 'Risk Management', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (96, '5', 'Budgeting', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (97, '6', 'Python', 'Expert', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (98, '6', 'Django', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (99, '6', 'PostgreSQL', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (100, '7', 'Docker', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (101, '7', 'Kubernetes', 'Intermediate', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (102, '7', 'AWS', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (103, '10', 'Operations Management', 'Expert', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (104, '10', 'Leadership', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (105, '10', 'Process Improvement', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (106, '12', 'Document Management', 'Expert', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (107, '12', 'Record Keeping', 'Advanced', '2025-10-12 18:52:30.264998+00');
INSERT INTO public.employee_skills VALUES (108, '12', 'Compliance', 'Advanced', '2025-10-12 18:52:30.264998+00');


--
-- Data for Name: employee_targets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.employee_targets VALUES (16, 'PR100', 'c1', 'Deliver Q2 operational OKRs', 'Execute quarterly plan', '2025-10-12 18:52:30.279041+00');
INSERT INTO public.employee_targets VALUES (17, 'PR100', 'c2', 'Monthly townhalls', 'Improve transparency', '2025-10-12 18:52:30.279041+00');
INSERT INTO public.employee_targets VALUES (18, 'PR100', 'c3', 'Implement 2 process improvements', 'Lean practices', '2025-10-12 18:52:30.279041+00');
INSERT INTO public.employee_targets VALUES (19, 'PR101', 'c1', 'Align Q3 departmental KPIs', 'Weekly check-ins', '2025-10-12 18:52:30.279041+00');
INSERT INTO public.employee_targets VALUES (20, 'PR101', 'c2', 'Improve cross-team updates', 'Bi-weekly reports', '2025-10-12 18:52:30.279041+00');


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.employees VALUES ('2', '20211234568', 'Sarah Johnson', 'sarah.johnson@mwsi.com', 'HR Manager', 'Human Resources', NULL, NULL, '2021-03-20', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=SJ', '+254-700-234567', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1982-11-10', '2025-10-12 18:45:23.990988+00', '2025-10-12 18:45:23.990988+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('10', '2019031010', 'David Manager', 'david.manager@mwsi.com', 'Operations Manager', 'Operations', NULL, NULL, '2019-03-10', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=DM', '+254-700-999999', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1980-07-22', '2025-10-12 18:45:23.990988+00', '2025-10-12 18:45:23.990988+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('1', '20221234567', 'John Smith', 'john.smith@mwsi.com', 'System Administrator', 'IT', 'Sarah Johnson', '2', '2022-01-15', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=JS', '+254-700-123456', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1985-06-15', '2025-10-12 18:45:23.990988+00', '2025-10-12 18:52:30.257842+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('5', '20201234571', 'Robert Wilson', 'robert.wilson@mwsi.com', 'Finance Director', 'Finance', NULL, '2', '2020-11-30', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=RW', '+254-700-567890', 'Mary Wilson (+254-700-567891)', 95000.00, 'male', 'Management', 'Permanent', 'Permanent', 'L', 'Meru', '25987654', 'A012345682Z', '3', 'Nairobi', 'Nyeri', 'P.O. Box 24680', '00100', 'Finance Department - Head Office', 'Masters (Finance)', 'Ministry of Water, Sanitation and Irrigation', '1978-12-18', '2025-10-12 18:47:57.404867+00', '2025-10-12 18:52:30.257842+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('12', '20211234572', 'Rita Registry', 'registry@mwsi.com', 'Registry Manager', 'Registry', NULL, '2', '2021-08-15', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=RR', '+254-700-888888', 'Paul Registry (+254-700-888889)', 80000.00, 'female', 'Management', 'Permanent', 'Permanent', 'J', 'Luhya', '30987654', 'A012345684Z', '2', 'Nairobi', 'Kakamega', 'P.O. Box 33556', '00100', 'Registry Department - Head Office', 'Degree (Records Management)', 'Ministry of Water, Sanitation and Irrigation', '1986-09-12', '2025-10-12 18:47:57.404867+00', '2025-10-12 18:52:30.257842+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('3', '20221234569', 'Michael Davis', 'michael.davis@mwsi.com', 'Software Developer', 'Engineering', 'David Manager', '10', '2022-07-10', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=MD', '+254-700-345678', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1990-04-01', '2025-10-12 18:45:23.990988+00', '2025-10-12 18:52:30.262081+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('4', '20231234570', 'Emily Chen', 'emily.chen@mwsi.com', 'Testing Role', 'Marketing', 'David Manager', '10', '2023-02-14', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=EC', '+25470045678988', 'David Chen (+254-700-456790)', 55000.00, 'female', 'Support', 'Contract', 'Contract', 'F', 'Kisii', '31234567', 'A012345681Z', '0', 'Nairobi', 'Nairobi', 'P.O. Box 13579', '00100', 'Marketing Department - Head Office', 'Degree (Marketing)', 'Ministry of Water, Sanitation and Irrigation', '1995-08-05', '2025-10-12 18:47:57.404867+00', '2025-10-15 09:43:40.787089+00', '', '', '', '', false, '', 'Ruaraka', NULL);
INSERT INTO public.employees VALUES ('6', '20210815001', 'Jane Smith', 'jane.smith@mwsi.com', 'Senior Developer', 'Engineering', 'David Manager', '10', '2021-08-15', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=JS2', '+254-700-666666', 'John Smith (+254-700-666667)', 85000.00, 'female', 'Technical', 'Permanent', 'Permanent', 'I', 'Kikuyu', '33445566', 'A012345685Z', '1', 'Nairobi', 'Nyeri', 'P.O. Box 44556', '00100', 'Engineering Department - Head Office', 'Degree (Computer Science)', 'Ministry of Water, Sanitation and Irrigation', '1988-05-20', '2025-10-12 18:47:57.404867+00', '2025-10-12 18:52:30.262081+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('7', '20220301002', 'Robert Chen', 'robert.chen@mwsi.com', 'DevOps Engineer', 'Engineering', 'David Manager', '10', '2022-03-01', 'active', 'https://api.dicebear.com/7.x/initials/svg?seed=RC', '+254-700-555555', 'Lisa Chen (+254-700-555556)', 80000.00, 'male', 'Technical', 'Permanent', 'Permanent', 'H', 'Luo', '34556677', 'A012345686Z', '0', 'Nairobi', 'Kisumu', 'P.O. Box 55667', '00100', 'Engineering Department - Head Office', 'Degree (Information Technology)', 'Ministry of Water, Sanitation and Irrigation', '1992-11-08', '2025-10-12 18:47:57.404867+00', '2025-10-12 18:52:30.262081+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('5c23d8d6-7bd0-4d17-89a3-44087e9dec19', NULL, 'Test User', 'test.user@example.com', 'Engineer', 'Engineering', NULL, NULL, NULL, 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-13 10:13:39.941105+00', '2025-10-13 10:13:39.941105+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('b792cba7-8403-4db4-acfc-f9839dfa5cc8', NULL, 'E2E Test', 'e2e@test.local', 'Engineer', 'Engineering', NULL, NULL, '2025-10-13', 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-13 10:29:57.697999+00', '2025-10-13 10:29:57.697999+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('d2e7c3b6-7507-4403-90b0-4e9d057317a5', NULL, 'E2E Test 2', 'e2e+1423148c-ea2b-4854-b8fd-636b1c813afe@test.local', 'Senior Engineer', 'Engineering', NULL, NULL, '2025-10-13', 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-13 10:30:15.002605+00', '2025-10-13 10:30:20.604656+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('96e18743-2bfd-488d-8edd-5b43f63b590b', '1985050284', 'Nyagah Kariuki Paul', 'nyagah@mwsi.com', 'HR Manager', NULL, NULL, NULL, '2025-10-09', 'inactive', '', '+25470023456', 'Robert Johnson (+254-700-234568)', 85000.00, 'female', 'Technical', 'Permanent', 'Permanent', 'B', 'Luo', '28123456', 'A012345679Z', '1', 'Mandera', 'Mandera', 'P.O. Box 54321', '00100', 'Human Resources - Head Office', 'Degree (Human Resource Management)', 'Ministry of Water, Sanitation and Irrigation', '2025-09-30', '2025-10-13 14:13:25.853677+00', '2025-10-13 19:34:56.656765+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('e3d9f09d-6cc2-4967-8748-938f252d8afc', '0987654321', 'Ken Mwangi', 'ken@mwsi.com', 'System Administrator', NULL, 'David Manager', '10', '2025-10-01', 'active', '', '+254722222222', 'Jane Manager (+254-700-777778)', 1200016.00, 'female', 'Management', 'Permanent', 'Permanent', 'B', 'Luo', '28123456', 'A012345678Z', '10', 'Garissa', 'Garissa', 'P.O. Box 12345', '00100', 'IT Department - Head Office', 'Degree (Human Resource Management)', 'Ministry of Water, Sanitation and Irrigation', '2025-09-30', '2025-10-13 16:09:20.396743+00', '2025-10-13 16:09:20.396743+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('d31aea4e-6d0b-4fc3-b858-9cbd7dccaabe', '0987654322', 'Ken Kibui Mwangi', 'mwangi@mwsi.com', 'Senior Engineer', NULL, 'David Manager', '10', '2025-10-10', 'active', '', '+25476655444566', 'Jane Manager (+254-700-777778)', 20000.00, 'male', 'Technical', 'Permanent', 'Permanent', 'A', 'Luo', '28123456', 'A012345678Z', '10', 'Taita-Taveta', 'Garissa', 'P.O. Box 12345', '00100', 'Marketing Department - Head Office', 'Degree (Computer Science)', 'Ministry of Water, Sanitation and Irrigation', '2025-09-30', '2025-10-13 16:15:41.968093+00', '2025-10-13 16:15:41.968093+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('4fd5ea2f-b1c7-4eb5-b4a7-399963392234', '0987654323', 'Ken Kibui TestingKin', 'mwanguui@mwsi.com', 'Operations Manager', NULL, NULL, NULL, '2025-10-09', 'active', '', '+25476655444566', 'Jane Manager (+254-700-777778)', 20000.00, 'female', 'Technical', 'Permanent', 'Permanent', 'E', 'Luo', '28123456', 'A012345678Z', '10', 'Taita-Taveta', 'Garissa', 'P.O. Box 12345', '00100', 'Human Resources - Head Office', 'Degree (Marketing)', 'Ministry of Water, Sanitation and Irrigation', '2025-10-03', '2025-10-13 17:16:10.641759+00', '2025-10-13 17:17:02.408663+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('78c11be6-3631-4628-a70b-5ab1a26dbac8', '0987654323', 'JohnTestingSubcounty Kibui TestingKin', 'yohana@mwsi.com', 'HR Manager', NULL, 'Ken Kibui Mwangi', 'adc23373-c0bc-4be7-8322-58f2f6d5cced', '2025-10-08', 'active', '', '+25476655444566', NULL, 20000.00, 'female', 'Management', 'Permanent', 'Permanent', 'E', 'Luo', '28123456', 'A012345678Z', '10', 'Wajir', 'Kakamega', 'P.O. Box 12345', '00100', 'Operations Department - Head Office', 'Degree (Marketing)', 'Ministry of Water, Sanitation and Irrigation', '2025-10-01', '2025-10-13 18:41:33.817341+00', '2025-10-13 19:43:41.3594+00', 'John Nguni Muthoka', 'wife', '+254704895391', 'johnmuthokak@gmail.com', false, '', 'Kakamega Central', NULL);
INSERT INTO public.employees VALUES ('72229518-1d15-4c03-ba3c-0ecc7ee4e6a4', '0987654323', 'TestingUI Kibui TestingKin', 'testingsub@mwsi.com', 'HR Manager', NULL, NULL, NULL, '2025-10-01', 'active', '', '+25476655444566', NULL, 20000.00, 'male', 'Technical', 'Permanent', 'Permanent', 'J', 'Luo', '28123456', 'A012345678Z', '10', 'Marsabit', 'Garissa', 'P.O. Box 12345', '00100', 'Operations Department - Head Office', 'Expert', 'Ministry of Water, Sanitation and Irrigation', '2025-10-01', '2025-10-13 19:09:55.749537+00', '2025-10-13 19:16:07.593575+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.employees VALUES ('802c9009-526c-40e5-8594-c48fd75f4177', '1982033699', 'David Kariuki MwangiTesting', 'odhiambo@mwsi.com', 'Finance Director', NULL, NULL, NULL, '2025-10-08', 'active', '', '+254700234567776', 'Jane Smith (+254-700-123457)', 75000.00, 'female', NULL, 'LOcal Testing', 'LOcal Testing', 'Z TESTING', 'Luo', '32456789', 'A012345678Z', '2', 'Mandera', 'Kilifi', 'P.O. Box 12345', '00100', 'Human Resources - Head Office', 'testing 2', 'Ministry of Water, Sanitation and Irrigation', '2025-10-02', '2025-10-13 14:42:12.627078+00', '2025-10-15 10:45:40.646212+00', '', '', '', '', false, '', 'Kaloleni', NULL);
INSERT INTO public.employees VALUES ('c6ca7c40-c7ed-4ece-95ac-6d0ac0a06bb3', '1234567890', 'John Nguni Muthoka', 'johnmuthokak@gmail.com', 'Operations Manager', NULL, 'David Manager', '10', '2025-10-07', 'active', '', '+254729104801', 'Jane Manager (+254-700-777778)', 110000.00, 'male', 'Management', 'Extended Service', 'Extended Service', 'B', 'Kamba', '32456789', 'A012345683Z', '1', 'Mombasa', 'Taita-Taveta', 'P.O. Box 22446', '00100', 'Human Resources - Head Office', 'Masters (Engineering Management)', 'Ministry of Water, Sanitation and Irrigation', '2010-01-10', '2025-10-13 14:59:02.399669+00', '2025-10-13 20:36:52.453988+00', 'Odhiambo Peter Mark', 'Spouse', '+254704895391', 'johnmuthokak@gmail.com', false, '', 'Wundanyi', NULL);


--
-- Data for Name: file_movements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.file_requests VALUES ('req-1', '1', '1', 'Birth_Certificate', '2', 'Sarah Johnson', 'Human Resources', 'pending', '2025-09-01 10:00:00+00', 'Needed for onboarding');
INSERT INTO public.file_requests VALUES ('req-2', '2', '2', 'National_ID_Card', '10', 'David Manager', 'Operations', 'pending', '2025-09-01 11:00:00+00', 'Verification');


--
-- Data for Name: leave_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.leave_requests VALUES ('L100', '10', 'David Manager', 'annual', '2025-08-01', '2025-08-10', 10, 'approved', 'Annual leave', '2025-07-15', 'Enjoy your break!', NULL, 'Sarah Johnson', '2025-07-16', '2025-10-12 18:47:57.427563+00');
INSERT INTO public.leave_requests VALUES ('L101', '10', 'David Manager', 'sick', '2025-09-01', '2025-09-03', 3, 'pending_manager', 'Medical', '2025-08-31', NULL, NULL, NULL, NULL, '2025-10-12 18:47:57.427563+00');
INSERT INTO public.leave_requests VALUES ('1', '3', 'Michael Davis', 'annual', '2024-03-25', '2024-03-29', 5, 'pending_manager', 'Family vacation', '2024-03-10', NULL, NULL, NULL, NULL, '2025-10-12 18:47:57.427563+00');
INSERT INTO public.leave_requests VALUES ('6', '3', 'Michael Davis', 'sick', '2025-09-10', '2025-09-12', 3, 'pending_hr', 'Medical recovery', '2025-09-09', NULL, NULL, NULL, NULL, '2025-10-12 18:47:57.427563+00');
INSERT INTO public.leave_requests VALUES ('7', '3', 'Michael Davis', 'emergency', '2025-09-15', '2025-09-16', 2, 'pending_manager', 'Family emergency', '2025-09-14', NULL, NULL, NULL, NULL, '2025-10-12 18:47:57.427563+00');
INSERT INTO public.leave_requests VALUES ('2', '4', 'Emily Chen', 'sick', '2024-03-15', '2024-03-16', 2, 'approved', 'Medical appointment', '2024-03-14', NULL, NULL, 'Sarah Johnson', '2024-03-14', '2025-10-12 18:47:57.427563+00');
INSERT INTO public.leave_requests VALUES ('3', '1', 'John Smith', 'study', '2024-04-01', '2024-04-05', 5, 'approved', 'Professional certification exam', '2024-03-01', NULL, NULL, 'Sarah Johnson', '2024-03-01', '2025-10-12 18:47:57.427563+00');
INSERT INTO public.leave_requests VALUES ('4', '1', 'John Smith', 'annual', '2025-09-20', '2025-09-25', 6, 'pending_hr', 'Travel abroad', '2025-09-10', NULL, NULL, NULL, NULL, '2025-10-12 18:47:57.427563+00');
INSERT INTO public.leave_requests VALUES ('5', '1', 'John Smith', 'sick', '2025-08-10', '2025-08-12', 3, 'pending_manager', 'Flu recovery', '2025-08-09', NULL, NULL, NULL, NULL, '2025-10-12 18:47:57.427563+00');


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notifications VALUES ('n-1', '2', 'New File Request', 'John Smith requested Birth Certificate for employee 1', '/employee-files', 'info', false, '2025-09-01 10:05:00+00');
INSERT INTO public.notifications VALUES ('n-2', '10', 'Leave Request Pending', 'Michael Davis submitted a leave request for manager approval', '/leave/requests', 'info', false, '2025-09-01 11:10:00+00');


--
-- Data for Name: performance_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.performance_reviews VALUES ('PR100', '10', 'David Manager', '2019031010', 'template-1', 'Q2 2025', 'Strong quarter with successful execution of all operational goals and team engagement initiatives.', NULL, NULL, NULL, 'completed', 4.70, 4.70, 'Excellent leadership and team management.', 'Consistently exceeds expectations.', '{"Deliver Q2 operational OKRs","Monthly townhalls","Implement 2 process improvements"}', 'Excellent performance this quarter. Strong technical skills and great team collaboration.', '[{"target": "Deliver Q2 operational OKRs", "criteriaId": "c1", "description": "Execute quarterly plan"}, {"target": "Monthly townhalls", "criteriaId": "c2", "description": "Improve transparency"}, {"target": "Implement 2 process improvements", "criteriaId": "c3", "description": "Lean practices"}]', '[{"score": 5, "comments": "Exceeded plan delivery", "criteriaId": "c1"}, {"score": 4, "comments": "Clear communication cadence", "criteriaId": "c2"}, {"score": 4, "comments": "Strong improvements", "criteriaId": "c3"}]', '[{"score": 5, "comments": "Successfully delivered all Q2 OKRs ahead of schedule", "criteriaId": "c1"}, {"score": 4, "comments": "Conducted monthly townhalls with high attendance and engagement", "criteriaId": "c2"}, {"score": 4, "comments": "Implemented 2 major process improvements that increased efficiency", "criteriaId": "c3"}]', '2025-12-01', 'HR System', '2025-06-30 00:00:00+00');
INSERT INTO public.performance_reviews VALUES ('PR101', '10', 'David Manager', '2019031010', 'template-1', 'Q3 2025', NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-01', 'HR System', '2025-09-01 00:00:00+00');
INSERT INTO public.performance_reviews VALUES ('PR001', '3', 'Michael Davis', '20221234569', 'template-1', 'Q1 2024', 'Excellent performance this quarter. Strong technical skills and great team collaboration.', NULL, NULL, NULL, 'completed', 4.50, 4.50, 'Outstanding technical delivery and team leadership.', 'Approved. Excellent performance across all criteria.', '{"Complete React migration project","Mentor junior developers","Improve code review process"}', 'Excellent performance this quarter. Strong technical skills and great team collaboration.', '[{"target": "Complete React migration project", "criteriaId": "c1", "description": "Focus on migration tasks."}, {"target": "Mentor junior developers", "criteriaId": "c2", "description": "Weekly mentorship sessions."}, {"target": "Improve code review process", "criteriaId": "c3", "description": "Document and share best practices."}]', '[{"score": 5, "comments": "Migration completed successfully", "criteriaId": "c1"}, {"score": 4, "comments": "Active mentorship observed", "criteriaId": "c2"}, {"score": 4, "comments": "Better review coverage", "criteriaId": "c3"}]', '[{"score": 5, "comments": "Successfully completed React migration with zero production issues", "criteriaId": "c1"}, {"score": 4, "comments": "Conducted weekly mentorship sessions with 2 junior developers", "criteriaId": "c2"}, {"score": 4, "comments": "Created comprehensive code review guidelines and improved team practices", "criteriaId": "c3"}]', '2024-06-30', 'Sarah Johnson', '2025-09-01 00:00:00+00');
INSERT INTO public.performance_reviews VALUES ('dbf7ff6d-6a83-4a3f-b4ef-0e55bceb8b5d', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.137+00');
INSERT INTO public.performance_reviews VALUES ('cbff6732-3bce-4ed0-80f8-1da8d79e23c3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.156+00');
INSERT INTO public.performance_reviews VALUES ('c44068cb-034e-4a4c-b66e-b0c765fb42bf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.163+00');
INSERT INTO public.performance_reviews VALUES ('4b271e54-a471-439a-8f38-87e1bd080db7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.16+00');
INSERT INTO public.performance_reviews VALUES ('0de3cc7b-72a0-46ac-a6a3-390ed5c574b2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.129+00');
INSERT INTO public.performance_reviews VALUES ('fc38f31b-84ce-46dd-bebc-a222d5e07e1e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.134+00');
INSERT INTO public.performance_reviews VALUES ('8a43ebd5-2cd8-4608-8b15-97ac388260fa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.303+00');
INSERT INTO public.performance_reviews VALUES ('67cfe95b-d5a2-40dc-9809-1ff9e22a09f3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.306+00');
INSERT INTO public.performance_reviews VALUES ('c450361f-ed3a-4cc4-975f-bbffcb6a4eb1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.309+00');
INSERT INTO public.performance_reviews VALUES ('60224497-1da9-4b16-acc8-6254f35de03d', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.311+00');
INSERT INTO public.performance_reviews VALUES ('ab8f9419-8b28-46e6-928a-1b6ff4710632', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.314+00');
INSERT INTO public.performance_reviews VALUES ('caff5313-bb1a-44c6-af47-2f67aae6a0b9', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.316+00');
INSERT INTO public.performance_reviews VALUES ('648d5989-fc4b-4fda-948a-a0334c7208b9', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.341+00');
INSERT INTO public.performance_reviews VALUES ('502caf31-2866-4506-905e-eea6d5006345', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.343+00');
INSERT INTO public.performance_reviews VALUES ('1e9752af-85a6-4213-bef4-7242ee816f75', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.344+00');
INSERT INTO public.performance_reviews VALUES ('1f0eb8e4-0cdc-4d97-8f3b-2df9d1e41fa9', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.35+00');
INSERT INTO public.performance_reviews VALUES ('24ca8748-4211-4039-bcc7-e7c37c2e2fd3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.354+00');
INSERT INTO public.performance_reviews VALUES ('49fbc55a-9d69-4881-809a-e3490afbcf99', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.356+00');
INSERT INTO public.performance_reviews VALUES ('a039d7b9-d58e-42c6-ae29-693f4532b955', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.369+00');
INSERT INTO public.performance_reviews VALUES ('86ed7ad2-cde4-41dd-9b6b-bc5b2be83f23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'draft', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:57:59.372+00');


--
-- Data for Name: performance_scores; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.performance_scores VALUES (19, 'PR100', 'c1', 'employee', 5, 'Successfully delivered all Q2 OKRs ahead of schedule', '2025-10-12 18:52:30.283732+00');
INSERT INTO public.performance_scores VALUES (20, 'PR100', 'c2', 'employee', 4, 'Conducted monthly townhalls with high attendance and engagement', '2025-10-12 18:52:30.283732+00');
INSERT INTO public.performance_scores VALUES (21, 'PR100', 'c3', 'employee', 4, 'Implemented 2 major process improvements that increased efficiency', '2025-10-12 18:52:30.283732+00');
INSERT INTO public.performance_scores VALUES (22, 'PR100', 'c1', 'manager', 5, 'Exceeded plan delivery', '2025-10-12 18:52:30.283732+00');
INSERT INTO public.performance_scores VALUES (23, 'PR100', 'c2', 'manager', 4, 'Clear communication cadence', '2025-10-12 18:52:30.283732+00');
INSERT INTO public.performance_scores VALUES (24, 'PR100', 'c3', 'manager', 4, 'Strong improvements', '2025-10-12 18:52:30.283732+00');


--
-- Data for Name: performance_template_criteria; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.performance_template_criteria VALUES (1, 'template-1', 'c1', 'Quality of Work', 40.00, 'Accuracy, thoroughness, and effectiveness.');
INSERT INTO public.performance_template_criteria VALUES (2, 'template-1', 'c2', 'Teamwork', 30.00, 'Collaboration and communication.');
INSERT INTO public.performance_template_criteria VALUES (3, 'template-1', 'c3', 'Initiative', 30.00, 'Proactiveness and problem-solving.');


--
-- Data for Name: performance_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.performance_templates VALUES ('template-1', 'Quarterly Appraisal', 'quarterly', 'Standard quarterly performance review template.', NULL, 'Sarah Johnson', '2025-09-01');


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.positions VALUES ('3', 'Marketing Manager', 'Marketing', 'filled', 'low', 15, '2024-02-15', '2024-03-15', 'We are seeking a Marketing Manager to develop and execute campaigns, manage digital channels, and lead a small team. Experience in B2B marketing is a plus.', 'Marketing Manager', 'Senior', 'Operations Department - Head Office', 'JG 11', 'Contract', '2025-10-12 18:47:57.419983+00', '{"Operations Department - Head Office"}', NULL, '2025-10-12 19:57:12.496649+00');
INSERT INTO public.positions VALUES ('2', 'Finance Director', 'Human Resources', 'open', 'medium', 10, '2025-10-15', '2025-10-31', '<p>The HR Assistant will support recruitment, onboarding, and employee engagement activities. Strong organizational and communication skills are required.</p>', 'Finance Director', 'Entry', 'Human Resources - Head Office', 'JG 6', 'Permanent', '2025-10-12 18:47:57.419983+00', '{"Human Resources - Head Office"}', 1200000, '2025-10-15 14:57:59.780385+00');
INSERT INTO public.positions VALUES ('1', 'Operations Manager', 'Engineering', 'open', 'high', 24, '2025-10-15', '2025-10-31', '<p>We are looking for a Senior Software Engineer with experience in full-stack development, React, and Node.js. You will lead a team of developers and collaborate with product managers to deliver scalable applications.</p><ul><li>deliver testing</li><li>deliver testing 2</li></ul>', 'Operations Manager', 'Senior', 'Nairobi HQ', 'JG 12', 'Permanent', '2025-10-12 18:47:57.419983+00', '{"Nairobi HQ"}', 450000, '2025-10-15 14:58:10.133756+00');
INSERT INTO public.positions VALUES ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'HR Manager', NULL, 'open', NULL, 5, '2025-09-01', '2025-11-30', '<p>Manage HR processes</p>', 'HR Manager', NULL, NULL, NULL, 'Permanent', '2025-10-12 19:57:17.781234+00', '{Nairobi}', 60000, '2025-10-15 14:58:19.277428+00');
INSERT INTO public.positions VALUES ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Testing position', NULL, 'open', NULL, 12, '2025-09-01', '2025-12-31', '<p>Build and maintain web applications</p>', 'Testing position', NULL, NULL, NULL, 'Permanent', '2025-10-12 19:57:17.781234+00', '{Nairobi}', 120000, '2025-10-15 14:58:25.474394+00');
INSERT INTO public.positions VALUES ('ea709a5b-f7ef-432d-b1d9-ba33a7dc6e3b', 'System Administrator', NULL, 'open', NULL, 0, '2025-10-15', '2025-10-23', '<p>Testing this feature</p>', 'System Administrator', NULL, NULL, NULL, 'Intern', '2025-10-15 15:01:13.384861+00', '{"Marketing Department - Head Office","Human Resources - Head Office"}', 300000, '2025-10-15 15:01:13.384861+00');


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.role_permissions VALUES ('admin', 'employee.view');
INSERT INTO public.role_permissions VALUES ('admin', 'employee.edit');
INSERT INTO public.role_permissions VALUES ('admin', 'employee.create');
INSERT INTO public.role_permissions VALUES ('admin', 'employee.delete');
INSERT INTO public.role_permissions VALUES ('admin', 'page.employee-files');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.requests');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.users');
INSERT INTO public.role_permissions VALUES ('hr_manager', 'employee.view');
INSERT INTO public.role_permissions VALUES ('hr_manager', 'employee.edit');
INSERT INTO public.role_permissions VALUES ('hr_manager', 'employee.create');
INSERT INTO public.role_permissions VALUES ('hr_manager', 'page.employee-files');
INSERT INTO public.role_permissions VALUES ('hr_staff', 'employee.view');
INSERT INTO public.role_permissions VALUES ('manager', 'employee.view');
INSERT INTO public.role_permissions VALUES ('employee', 'employee.view');
INSERT INTO public.role_permissions VALUES ('registry_manager', 'page.registry.requests');
INSERT INTO public.role_permissions VALUES ('admin', 'page.registry.requests');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.roles');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.settings');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.data');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.performance-templates');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.department-goals');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.training-management');
INSERT INTO public.role_permissions VALUES ('admin', 'page.admin.system-logs');
INSERT INTO public.role_permissions VALUES ('hr_staff', 'employee.edit');
INSERT INTO public.role_permissions VALUES ('hr_staff', 'page.employee-files');
INSERT INTO public.role_permissions VALUES ('manager', 'page.employee-files');
INSERT INTO public.role_permissions VALUES ('registry_manager', 'employee.view');
INSERT INTO public.role_permissions VALUES ('registry_manager', 'page.employee-files');
INSERT INTO public.role_permissions VALUES ('testing', '');


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.roles VALUES ('admin', 'Administrator', false, '{}', '2025-10-12 18:46:02.183296+00');
INSERT INTO public.roles VALUES ('hr_manager', 'HR Manager', false, '{}', '2025-10-12 18:46:02.183296+00');
INSERT INTO public.roles VALUES ('hr_staff', 'HR Staff', false, '{}', '2025-10-12 18:46:02.183296+00');
INSERT INTO public.roles VALUES ('manager', 'Manager', false, '{}', '2025-10-12 18:46:02.183296+00');
INSERT INTO public.roles VALUES ('employee', 'Employee', false, '{}', '2025-10-12 18:46:02.183296+00');
INSERT INTO public.roles VALUES ('registry_manager', 'Registry Manager', false, '{}', '2025-10-12 18:46:02.183296+00');
INSERT INTO public.roles VALUES ('testing', 'Testing', false, '{}', '2025-10-12 18:46:02.183296+00');


--
-- Data for Name: system_designations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_designations VALUES ('System Administrator', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('HR Manager', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('Operations Manager', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('Software Developer', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('Marketing Coordinator', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('Finance Director', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('Senior Developer', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('DevOps Engineer', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('Registry Manager', '2025-10-12 18:47:57.463333+00');
INSERT INTO public.system_designations VALUES ('Testing position', '2025-10-15 14:22:26.185114+00');


--
-- Data for Name: system_engagement_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_engagement_types VALUES ('Permanent', '2025-10-12 18:47:57.474085+00');
INSERT INTO public.system_engagement_types VALUES ('Extended Service', '2025-10-12 18:47:57.474085+00');
INSERT INTO public.system_engagement_types VALUES ('Local Contract', '2025-10-12 18:47:57.474085+00');
INSERT INTO public.system_engagement_types VALUES ('Intern', '2025-10-12 18:47:57.474085+00');
INSERT INTO public.system_engagement_types VALUES ('Temporary', '2025-10-12 18:47:57.474085+00');


--
-- Data for Name: system_ethnicities; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_ethnicities VALUES ('Kikuyu', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Luo', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Luhya', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Kalenjin', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Kamba', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Somali', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Meru', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Mijikenda', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Maasai', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Embu', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Kisii', '2025-10-12 18:47:57.476603+00');
INSERT INTO public.system_ethnicities VALUES ('Other', '2025-10-12 18:47:57.476603+00');


--
-- Data for Name: system_job_groups; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_job_groups VALUES ('G', '2025-10-12 18:47:57.471118+00');
INSERT INTO public.system_job_groups VALUES ('J', '2025-10-12 18:47:57.471118+00');
INSERT INTO public.system_job_groups VALUES ('K', '2025-10-12 18:47:57.471118+00');
INSERT INTO public.system_job_groups VALUES ('H', '2025-10-12 18:47:57.471118+00');
INSERT INTO public.system_job_groups VALUES ('F', '2025-10-12 18:47:57.471118+00');
INSERT INTO public.system_job_groups VALUES ('L', '2025-10-12 18:47:57.471118+00');
INSERT INTO public.system_job_groups VALUES ('I', '2025-10-12 18:47:57.471118+00');


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: system_skill_levels; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_skill_levels VALUES ('Degree (Human Resource Management)', '2025-10-12 18:47:57.465909+00');
INSERT INTO public.system_skill_levels VALUES ('MBA', '2025-10-12 18:47:57.465909+00');
INSERT INTO public.system_skill_levels VALUES ('Degree (Computer Science)', '2025-10-12 18:47:57.465909+00');
INSERT INTO public.system_skill_levels VALUES ('Degree (Marketing)', '2025-10-12 18:47:57.465909+00');
INSERT INTO public.system_skill_levels VALUES ('Masters (Finance)', '2025-10-12 18:47:57.465909+00');
INSERT INTO public.system_skill_levels VALUES ('Degree (Records Management)', '2025-10-12 18:47:57.465909+00');
INSERT INTO public.system_skill_levels VALUES ('Senior', '2025-10-12 18:47:57.465909+00');
INSERT INTO public.system_skill_levels VALUES ('Entry', '2025-10-12 18:47:57.465909+00');
INSERT INTO public.system_skill_levels VALUES ('test 1', '2025-10-15 10:36:47.187065+00');
INSERT INTO public.system_skill_levels VALUES ('testing 2', '2025-10-15 10:38:15.951056+00');


--
-- Data for Name: system_stations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_stations VALUES ('IT Department - Head Office', '2025-10-12 18:47:57.468594+00');
INSERT INTO public.system_stations VALUES ('Human Resources - Head Office', '2025-10-12 18:47:57.468594+00');
INSERT INTO public.system_stations VALUES ('Operations Department - Head Office', '2025-10-12 18:47:57.468594+00');
INSERT INTO public.system_stations VALUES ('Engineering Department - Head Office', '2025-10-12 18:47:57.468594+00');
INSERT INTO public.system_stations VALUES ('Marketing Department - Head Office', '2025-10-12 18:47:57.468594+00');
INSERT INTO public.system_stations VALUES ('Finance Department - Head Office', '2025-10-12 18:47:57.468594+00');
INSERT INTO public.system_stations VALUES ('Registry Department - Head Office', '2025-10-12 18:47:57.468594+00');
INSERT INTO public.system_stations VALUES ('Station for testing', '2025-10-15 13:43:22.816018+00');


--
-- Data for Name: training_records; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.training_records VALUES ('1', '1', 'Cybersecurity Awareness Training', 'mandatory', 'completed', '2024-02-15', '2025-02-15', 'CyberSafe Institute', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('2', '2', 'Leadership Development Program', 'development', 'in_progress', NULL, NULL, 'Management Excellence Academy', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('3', '3', 'React Advanced Patterns', 'development', 'completed', '2024-03-10', NULL, 'Tech Learning Hub', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('T100', '3', 'Data Protection & GDPR', 'compliance', 'in_progress', NULL, '2025-11-30', 'Legal Compliance Corp', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('T101', '3', 'Workplace Safety Basics', 'mandatory', 'not_started', NULL, NULL, 'SafetyFirst Academy', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('T102', '3', 'Advanced React Patterns', 'development', 'in_progress', NULL, '2025-06-30', 'Tech Learning Hub', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('dm1', '10', 'Cybersecurity Awareness Training', 'mandatory', 'in_progress', '2024-03-01', '2025-03-01', 'CyberSafe Institute', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('dm2', '10', 'Leadership Development Program', 'development', 'completed', '2024-06-15', '2025-06-15', 'Management Excellence Academy', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('dm3', '10', 'Data Protection & GDPR Compliance', 'compliance', 'in_progress', NULL, NULL, 'Legal Compliance Corp', '2025-10-12 18:47:57.423273+00', false);
INSERT INTO public.training_records VALUES ('d802f4c4-9602-4829-8a54-782bc865987b', '1', 'Cybersecurity Awareness Training (smoke)', 'mandatory', 'not_started', NULL, NULL, 'CyberSafe Institute', '2025-10-12 21:35:37.697+00', false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users VALUES ('1', '1', 'john.smith@mwsi.com', 'John Smith', 'employee', 'demo123', 'active', '2025-10-12 18:45:23.996168+00', '2025-10-12 18:45:23.996168+00');
INSERT INTO public.users VALUES ('2', '2', 'sarah.johnson@mwsi.com', 'Sarah Johnson', 'hr_manager', 'demo123', 'active', '2025-10-12 18:45:23.996168+00', '2025-10-12 18:45:23.996168+00');
INSERT INTO public.users VALUES ('10', '10', 'david.manager@mwsi.com', 'David Manager', 'manager', 'demo123', 'active', '2025-10-12 18:45:23.996168+00', '2025-10-12 18:45:23.996168+00');
INSERT INTO public.users VALUES ('admin-test', NULL, 'admin.test@mwsi.com', 'Test Admin', 'admin', 'demo123', 'active', '2025-10-12 18:45:23.996168+00', '2025-10-12 18:45:23.996168+00');
INSERT INTO public.users VALUES ('admin-001', NULL, 'admin@mwsi.com', 'Main Admin', 'admin', 'demo123', 'active', '2025-10-12 18:51:04.310531+00', '2025-10-12 18:51:04.310531+00');
INSERT INTO public.users VALUES ('adc23373-c0bc-4be7-8322-58f2f6d5cced', 'd31aea4e-6d0b-4fc3-b858-9cbd7dccaabe', 'mwangi@mwsi.com', 'Ken Kibui Mwangi', 'manager', NULL, 'active', '2025-10-13 16:22:20.802367+00', '2025-10-13 17:15:07.619012+00');
INSERT INTO public.users VALUES ('testing-user', NULL, 'testing@mwsi.com', 'Testing User', 'registry_staff', 'demo123', 'active', '2025-10-12 18:51:04.310531+00', '2025-10-14 13:13:17.418702+00');
INSERT INTO public.users VALUES ('221be415-07cd-40a5-a0ae-7a82e838ae3e', 'c6ca7c40-c7ed-4ece-95ac-6d0ac0a06bb3', 'johnmuthokak@gmail.com', 'John Nguni Muthoka', 'hr_staff', NULL, 'active', '2025-10-13 15:05:34.687027+00', '2025-10-14 13:41:22.574473+00');
INSERT INTO public.users VALUES ('3', '3', 'michael.davis@mwsi.com', 'Michael Davis', 'registry_staff', 'demo123', 'active', '2025-10-12 18:45:23.996168+00', '2025-10-14 14:09:36.103225+00');
INSERT INTO public.users VALUES ('4', '4', 'emily.chen@mwsi.com', 'Emily Chen', 'employee', 'demo123', 'active', '2025-10-12 18:51:04.310531+00', '2025-10-15 09:43:41.086636+00');


--
-- Name: disciplinary_case_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.disciplinary_case_updates_id_seq', 36, true);


--
-- Name: employee_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_skills_id_seq', 109, true);


--
-- Name: employee_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_targets_id_seq', 20, true);


--
-- Name: file_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.file_movements_id_seq', 1, false);


--
-- Name: performance_scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.performance_scores_id_seq', 24, true);


--
-- Name: performance_template_criteria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.performance_template_criteria_id_seq', 12, true);


--
-- Name: department_goals department_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.department_goals
    ADD CONSTRAINT department_goals_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: disciplinary_case_updates disciplinary_case_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disciplinary_case_updates
    ADD CONSTRAINT disciplinary_case_updates_pkey PRIMARY KEY (id);


--
-- Name: disciplinary_cases disciplinary_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disciplinary_cases
    ADD CONSTRAINT disciplinary_cases_pkey PRIMARY KEY (id);


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (name);


--
-- Name: employee_files employee_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_files
    ADD CONSTRAINT employee_files_pkey PRIMARY KEY (employee_id);


--
-- Name: employee_skills employee_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_skills
    ADD CONSTRAINT employee_skills_pkey PRIMARY KEY (id);


--
-- Name: employee_targets employee_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_targets
    ADD CONSTRAINT employee_targets_pkey PRIMARY KEY (id);


--
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: file_movements file_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_movements
    ADD CONSTRAINT file_movements_pkey PRIMARY KEY (id);


--
-- Name: file_requests file_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_requests
    ADD CONSTRAINT file_requests_pkey PRIMARY KEY (id);


--
-- Name: leave_requests leave_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: performance_reviews performance_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_pkey PRIMARY KEY (id);


--
-- Name: performance_scores performance_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_scores
    ADD CONSTRAINT performance_scores_pkey PRIMARY KEY (id);


--
-- Name: performance_template_criteria performance_template_criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_template_criteria
    ADD CONSTRAINT performance_template_criteria_pkey PRIMARY KEY (id);


--
-- Name: performance_template_criteria performance_template_criteria_template_id_criteria_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_template_criteria
    ADD CONSTRAINT performance_template_criteria_template_id_criteria_id_key UNIQUE (template_id, criteria_id);


--
-- Name: performance_templates performance_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_templates
    ADD CONSTRAINT performance_templates_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_key);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: system_designations system_designations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_designations
    ADD CONSTRAINT system_designations_pkey PRIMARY KEY (name);


--
-- Name: system_engagement_types system_engagement_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_engagement_types
    ADD CONSTRAINT system_engagement_types_pkey PRIMARY KEY (name);


--
-- Name: system_ethnicities system_ethnicities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_ethnicities
    ADD CONSTRAINT system_ethnicities_pkey PRIMARY KEY (name);


--
-- Name: system_job_groups system_job_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_job_groups
    ADD CONSTRAINT system_job_groups_pkey PRIMARY KEY (name);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: system_skill_levels system_skill_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_skill_levels
    ADD CONSTRAINT system_skill_levels_pkey PRIMARY KEY (name);


--
-- Name: system_stations system_stations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_stations
    ADD CONSTRAINT system_stations_pkey PRIMARY KEY (name);


--
-- Name: training_records training_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_records
    ADD CONSTRAINT training_records_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: disciplinary_cases_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX disciplinary_cases_employee_idx ON public.disciplinary_cases USING btree (employee_id);


--
-- Name: idx_department_goals_department; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_department_goals_department ON public.department_goals USING btree (department);


--
-- Name: idx_employee_skills_employee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_skills_employee_id ON public.employee_skills USING btree (employee_id);


--
-- Name: idx_employees_department; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_department ON public.employees USING btree (department);


--
-- Name: idx_leave_requests_employee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leave_requests_employee_id ON public.leave_requests USING btree (employee_id);


--
-- Name: idx_performance_reviews_employee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_performance_reviews_employee_id ON public.performance_reviews USING btree (employee_id);


--
-- Name: idx_positions_department; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_positions_department ON public.positions USING btree (department);


--
-- Name: idx_positions_designation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_positions_designation ON public.positions USING btree (designation);


--
-- Name: idx_positions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_positions_status ON public.positions USING btree (status);


--
-- Name: idx_training_records_employee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_training_records_employee_id ON public.training_records USING btree (employee_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: employees update_employees_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: disciplinary_case_updates disciplinary_case_updates_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disciplinary_case_updates
    ADD CONSTRAINT disciplinary_case_updates_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.disciplinary_cases(id) ON DELETE CASCADE;


--
-- Name: disciplinary_cases disciplinary_cases_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disciplinary_cases
    ADD CONSTRAINT disciplinary_cases_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_files employee_files_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_files
    ADD CONSTRAINT employee_files_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_skills employee_skills_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_skills
    ADD CONSTRAINT employee_skills_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_targets employee_targets_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_targets
    ADD CONSTRAINT employee_targets_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.performance_reviews(id) ON DELETE CASCADE;


--
-- Name: file_movements file_movements_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_movements
    ADD CONSTRAINT file_movements_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: file_requests file_requests_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_requests
    ADD CONSTRAINT file_requests_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.employee_files(employee_id) ON DELETE CASCADE;


--
-- Name: leave_requests leave_requests_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: performance_reviews performance_reviews_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: performance_reviews performance_reviews_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.performance_templates(id);


--
-- Name: performance_scores performance_scores_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_scores
    ADD CONSTRAINT performance_scores_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.performance_reviews(id) ON DELETE CASCADE;


--
-- Name: performance_template_criteria performance_template_criteria_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_template_criteria
    ADD CONSTRAINT performance_template_criteria_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.performance_templates(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: training_records training_records_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_records
    ADD CONSTRAINT training_records_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: users users_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict a6PGKcMFZO0TvW67EULqo2hR9mlwK3GSVkmBot6b6EgVeFeCSewfCFHGnKggvY7

